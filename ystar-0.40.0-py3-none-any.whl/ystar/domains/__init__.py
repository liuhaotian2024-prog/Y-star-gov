"""
Y* Domain Packs

Domain Packs are the second layer of Y*'s three-layer architecture:

  Layer 1  ystar/ (kernel)  — industry-agnostic constraint compiler
  Layer 2  domains/          — pluggable domain vocabulary and contract templates
  Layer 3  scenarios/        — full scenario experiments within a domain

A domain pack provides:
  - Domain vocabulary (DomainVocabulary)
  - Domain constitutional contract (ConstitutionalContract)
  - Pre-built domain IntentContracts
  - Domain prefill extensions (additional Source patterns)

Usage:
  from ystar.domains.finance import FinanceDomainPack
  pack = FinanceDomainPack()
  constitution = pack.constitutional_contract()
  contract = pack.make_contract(role="execution_agent", context={...})
"""
from abc import ABC, abstractmethod
from typing import Optional


class DomainPack(ABC):
    """
    Y* domain pack base class.
    All domain packs inherit from this class to ensure substitutability.

    Mandatory interface:
      domain_name          — short identifier, e.g. "finance"
      version              — SemVer string, e.g. "1.0.0"
      constitutional_contract() — returns ConstitutionalContract
      vocabulary()         — returns the domain vocabulary dict
      make_contract(role)  — returns IntentContract for a given role

    Optional interface (provided with a default implementation):
      describe()           — human-readable summary line
      schema_version       — config schema version (for auditing)
    """

    @property
    @abstractmethod
    def domain_name(self) -> str:
        """Domain name, e.g. 'finance', 'devops', 'healthcare'."""

    @property
    @abstractmethod
    def version(self) -> str:
        """Domain pack version (SemVer), e.g. '1.0.0'."""

    @property
    def schema_version(self) -> str:
        """
        Config schema version for this pack (used for auditability).
        Override in subclasses if the pack supports external configuration.
        Returns 'n/a' by default.
        """
        return "n/a"

    @abstractmethod
    def constitutional_contract(self):
        """
        Return the constitutional contract for this domain (ConstitutionalContract).
        Contains global constraints for this domain that can never be relaxed.
        """

    @abstractmethod
    def vocabulary(self) -> dict:
        """
        Return the domain vocabulary dict:
        {
          "deny_keywords":    [...]   # domain-specific deny keywords
          "role_names":       [...]   # role names available via make_contract()
          "param_names":      [...]   # important parameter names
          "env_keywords":     [...]   # environment/context keywords
        }
        """

    def make_contract(self, role: str, context: dict = None):
        """
        Return the IntentContract for the given role.
        Override in subclasses to provide role-specific contracts.
        Default implementation returns an empty contract.
        """
        from ystar import IntentContract
        return IntentContract()

    def describe(self) -> str:
        """Return a one-line human-readable summary of this pack."""
        roles = self.vocabulary().get("role_names", [])
        return (
            f"DomainPack(domain={self.domain_name!r}, "
            f"version={self.version!r}, "
            f"roles={len(roles)})"
        )
